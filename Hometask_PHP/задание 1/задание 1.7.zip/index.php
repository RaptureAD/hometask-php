<?php

echo date('r');