<?php

echo 'привет, мир';